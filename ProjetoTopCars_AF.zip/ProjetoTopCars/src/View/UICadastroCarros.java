/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;
import Conexoes.MySQL;
import Objects.Carro;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author alope
 */
public class UICadastroCarros extends javax.swing.JFrame {
    MySQL conectar = new MySQL();
    Carro novoCarro = new Carro();
    /**
     * Creates new form UICadastroCarros
     */
    public UICadastroCarros() {
        initComponents();
    }
        private void CadastrarCarro(Carro novoCarro){
        this.conectar.conectaBanco();
        
        novoCarro.setModelo(txtModelo.getText());
        novoCarro.setCor(txtCor.getText());
        novoCarro.setAno((String)cbxAno.getSelectedItem());
        novoCarro.setMarca(txtMarca.getText());
        novoCarro.setPlaca(txtPlaca.getText());
        novoCarro.setCarroceria((String)cbxCarroceria.getSelectedItem());
        novoCarro.setMotor(txtMotor.getText());
        novoCarro.setCarroceria((String)cbxCombustivel.getSelectedItem());
        novoCarro.setCombustivel((String)cbxCambio.getSelectedItem());
        novoCarro.setCambio((String)cbxCarroceria.getSelectedItem());
    
    try {
            this.conectar.insertSQL ("INSERT INTO veiculo ("
                + "modelo,"
                + "cor,"
                + "ano,"
                + "marca,"
                + "placa,"
                + "carroceria,"
                + "motor,"
                + "combustivel,"
                + "cambio"
            + ") VALUES ("
                + "'" + novoCarro.getModelo() + "',"
                + "'" + novoCarro.getCor() + "',"
                + "'" + novoCarro.getAno() + "',"
                + "'" + novoCarro.getMarca() + "',"
                + "'" + novoCarro.getPlaca() + "',"
                + "'" + novoCarro.getCarroceria() + "',"
                + "'" + novoCarro.getMotor() + "',"
                + "'" + novoCarro.getCombustivel() + "',"
                + "'" + novoCarro.getCambio() + "'"
            + ");");
            JOptionPane.showMessageDialog(null, "Carro cadastrado com sucesso");
        } catch (Exception e){
            System.out.println("Erro ao cadastrar carro " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar carro");
        } finally {
            this.conectar.fechaBanco();}
    }
    
private void BuscarCarro (Carro novoCarro){
        this.conectar.conectaBanco();
        
        String consultarPlaca = this.txtConsultaCarro.getText();
        
        try {
            this.conectar.executarSQL(
                    "SELECT "
                + "modelo, "
                + "cor,"
                + "ano, "
                + "marca, "
                + "placa, "
                + "carroceria, "
                + "motor, "
                + "combustivel, "
                + "cambio "
                    + " FROM"
                        + " veiculo"
                    + " WHERE"
                        + " placa = '" + consultarPlaca + "'" + ";");
            while (this.conectar.getResultSet().next()){
                novoCarro.setModelo(this.conectar.getResultSet().getString(1));
                novoCarro.setCor(this.conectar.getResultSet().getString(2));
                novoCarro.setAno(this.conectar.getResultSet().getString(3));
                novoCarro.setMarca(this.conectar.getResultSet().getString(4));
                novoCarro.setPlaca(this.conectar.getResultSet().getString(5));
                novoCarro.setCarroceria(this.conectar.getResultSet().getString(9));
                novoCarro.setMotor(this.conectar.getResultSet().getString(7));
                novoCarro.setCombustivel(this.conectar.getResultSet().getString(6));
                novoCarro.setCambio(this.conectar.getResultSet().getString(8));
            }
            
            if(novoCarro.getPlaca() == ""){
                JOptionPane.showMessageDialog(null, "Carro não encontrado!");
            }
        } catch (Exception e){
            System.out.println("Erro ao consultar carro " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar carro!");
        } finally{
            txtModelo.setText(novoCarro.getModelo());
            txtCor.setText(novoCarro.getCor());
            cbxAno.setSelectedItem(novoCarro.getAno());
            txtMarca.setText(novoCarro.getMarca());
            txtPlaca.setText(novoCarro.getPlaca());
            cbxCarroceria.setSelectedItem(novoCarro.getCarroceria());
            txtMotor.setText(novoCarro.getMotor());
            cbxCombustivel.setSelectedItem(novoCarro.getCombustivel());
            cbxCambio.setSelectedItem(novoCarro.getCambio());
            this.conectar.fechaBanco();
        }
    }
    public void AtualizarCarro(Carro novoCarro){
        this.conectar.conectaBanco();
        
        String consultarPlaca = this.txtConsultaCarro.getText();
        
        novoCarro.setModelo(txtModelo.getText());
        novoCarro.setCor(txtCor.getText());
        novoCarro.setAno((String)cbxAno.getSelectedItem());
        novoCarro.setMarca(txtMarca.getText());
        novoCarro.setPlaca(txtPlaca.getText());
        novoCarro.setCarroceria((String)cbxCarroceria.getSelectedItem());
        novoCarro.setMotor(txtMotor.getText());
        novoCarro.setCarroceria((String)cbxCombustivel.getSelectedItem());
        novoCarro.setCombustivel((String)cbxCambio.getSelectedItem());
        novoCarro.setCambio((String)cbxCarroceria.getSelectedItem());
        
        try{
            this.conectar.updateSQL(
                    "UPDATE veiculo SET " + "modelo = " + "'" + novoCarro.getModelo() + "',"
                    + "cor = " + "'" + novoCarro.getCor() + "',"
                    + "ano = " + "'" + novoCarro.getAno() + "',"
                    + "marca = " + "'" + novoCarro.getMarca() + "',"
                    + "placa = " + "'" + novoCarro.getPlaca() + "',"
                    + "carroceria = " + "'" + novoCarro.getCarroceria() + "',"
                    + "motor = " + "'" + novoCarro.getMotor() + "',"
                    + "combustivel = " + "'" + novoCarro.getCombustivel() + "',"
                    + "cambio = " + "'" + novoCarro.getCambio() + "'"       
                    + " WHERE " + "placa = '" + consultarPlaca + "'" + ";");
            JOptionPane.showMessageDialog(null, "Veículo atualizado com sucesso");
                
        }catch (Exception e){
            System.out.println("Erro ao atualizar veículo " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao atualizar veículo!");
        }finally{
            this.conectar.fechaBanco();
        }
    }
    public void DeletarCarros(Carro novoCarro){
        this.conectar.conectaBanco();
        
        String consultarPlaca = this.txtConsultaCarro.getText();
        
        novoCarro.setModelo(txtModelo.getText());
        novoCarro.setCor(txtCor.getText());
        novoCarro.setAno((String)cbxAno.getSelectedItem());
        novoCarro.setMarca(txtMarca.getText());
        novoCarro.setPlaca(txtPlaca.getText());
        novoCarro.setCarroceria((String)cbxCarroceria.getSelectedItem());
        novoCarro.setMotor(txtMotor.getText());
        novoCarro.setCarroceria((String)cbxCombustivel.getSelectedItem());
        novoCarro.setCombustivel((String)cbxCambio.getSelectedItem());
        novoCarro.setCambio((String)cbxCarroceria.getSelectedItem());
        
        try{
            this.conectar.deleteSQL(
                    "DELETE FROM veiculo WHERE " + "placa = '" + consultarPlaca + "'" + ";");
            JOptionPane.showMessageDialog(null, "Veículo deletado com sucesso");
                
        }catch (Exception e){
            System.out.println("Erro ao deletar Veículo " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao deletar Veículo!");
        }finally{
            this.conectar.fechaBanco();     
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblportas = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtPlaca = new javax.swing.JTextField();
        txtMotor = new javax.swing.JTextField();
        lblAno = new javax.swing.JLabel();
        cbxAno = new javax.swing.JComboBox<>();
        lblMarca = new javax.swing.JLabel();
        lblmodelo = new javax.swing.JLabel();
        txtMarca = new javax.swing.JTextField();
        txtModelo = new javax.swing.JTextField();
        lblcarroceria = new javax.swing.JLabel();
        cbxCarroceria = new javax.swing.JComboBox<>();
        lblcor = new javax.swing.JLabel();
        txtCor = new javax.swing.JTextField();
        txtConsultaCarro = new javax.swing.JTextField();
        lblportas1 = new javax.swing.JLabel();
        cbxCombustivel = new javax.swing.JComboBox<>();
        cbxCambio = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        bttnAtualizarVeiculo = new javax.swing.JButton();
        bttnCadastrarVeiculo = new javax.swing.JButton();
        bttnDeletarVeiculo = new javax.swing.JButton();
        bttnBuscarPlaca = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        bttnMenu = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        lblportas.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        lblportas.setForeground(new java.awt.Color(0, 0, 0));
        lblportas.setText("Placa:");

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Câmbio:");

        txtPlaca.setBackground(new java.awt.Color(255, 255, 255));
        txtPlaca.setForeground(new java.awt.Color(0, 0, 0));

        txtMotor.setBackground(new java.awt.Color(255, 255, 255));
        txtMotor.setForeground(new java.awt.Color(0, 0, 0));

        lblAno.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        lblAno.setForeground(new java.awt.Color(0, 0, 0));
        lblAno.setText("Ano:");

        cbxAno.setBackground(new java.awt.Color(255, 255, 255));
        cbxAno.setForeground(new java.awt.Color(0, 0, 0));
        cbxAno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022" }));

        lblMarca.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        lblMarca.setForeground(new java.awt.Color(0, 0, 0));
        lblMarca.setText("Marca:");

        lblmodelo.setBackground(new java.awt.Color(204, 204, 204));
        lblmodelo.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        lblmodelo.setForeground(new java.awt.Color(0, 0, 0));
        lblmodelo.setText("Modelo:");

        txtMarca.setBackground(new java.awt.Color(255, 255, 255));
        txtMarca.setForeground(new java.awt.Color(0, 0, 0));

        txtModelo.setBackground(new java.awt.Color(255, 255, 255));
        txtModelo.setForeground(new java.awt.Color(0, 0, 0));

        lblcarroceria.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        lblcarroceria.setForeground(new java.awt.Color(0, 0, 0));
        lblcarroceria.setText("Carroceria:");

        cbxCarroceria.setBackground(new java.awt.Color(255, 255, 255));
        cbxCarroceria.setForeground(new java.awt.Color(0, 0, 0));
        cbxCarroceria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SUV", "HATCHBACK", "SEDAN", "PICAPE" }));

        lblcor.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        lblcor.setForeground(new java.awt.Color(0, 0, 0));
        lblcor.setText("Cor:");

        txtCor.setBackground(new java.awt.Color(255, 255, 255));
        txtCor.setForeground(new java.awt.Color(0, 0, 0));

        txtConsultaCarro.setBackground(new java.awt.Color(255, 255, 255));
        txtConsultaCarro.setForeground(new java.awt.Color(0, 0, 0));

        lblportas1.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        lblportas1.setForeground(new java.awt.Color(0, 0, 0));
        lblportas1.setText("Insira a placa do carro:");

        cbxCombustivel.setBackground(new java.awt.Color(255, 255, 255));
        cbxCombustivel.setForeground(new java.awt.Color(0, 0, 0));
        cbxCombustivel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Álcool", "Gasolina", "Gás Natural" }));

        cbxCambio.setBackground(new java.awt.Color(255, 255, 255));
        cbxCambio.setForeground(new java.awt.Color(0, 0, 0));
        cbxCambio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manual", "Automático" }));

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Tipo do motor:");

        jLabel12.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Tipo de combustível:");

        bttnAtualizarVeiculo.setText("Atualizar");
        bttnAtualizarVeiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnAtualizarVeiculoActionPerformed(evt);
            }
        });

        bttnCadastrarVeiculo.setText("Cadastrar");
        bttnCadastrarVeiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnCadastrarVeiculoActionPerformed(evt);
            }
        });

        bttnDeletarVeiculo.setText("Apagar");
        bttnDeletarVeiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnDeletarVeiculoActionPerformed(evt);
            }
        });

        bttnBuscarPlaca.setText("Buscar");
        bttnBuscarPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnBuscarPlacaActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 255));
        jLabel1.setText("Cadastro de Veículos");

        bttnMenu.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 11)); // NOI18N
        bttnMenu.setText("Voltar para o Menu");
        bttnMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblmodelo)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblcor))
                        .addGap(46, 46, 46)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblcarroceria)
                            .addComponent(cbxCarroceria, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtCor, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxAno, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lblAno)
                                .addComponent(lblMarca)
                                .addComponent(lblportas)
                                .addComponent(txtPlaca, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(46, 46, 46)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMotor, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxCombustivel, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxCambio, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12)
                            .addComponent(jLabel10))))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblportas1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtConsultaCarro, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(bttnBuscarPlaca)
                                .addGap(96, 96, 96)
                                .addComponent(bttnAtualizarVeiculo)
                                .addGap(27, 27, 27)
                                .addComponent(bttnDeletarVeiculo)))
                        .addContainerGap(149, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(bttnMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(372, Short.MAX_VALUE)
                    .addComponent(bttnCadastrarVeiculo)
                    .addGap(205, 205, 205)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(bttnMenu)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblmodelo)
                    .addComponent(lblcarroceria))
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxCarroceria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblcor)
                    .addComponent(jLabel11))
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMotor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAno)
                    .addComponent(jLabel12))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbxCombustivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxAno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMarca)
                    .addComponent(jLabel10))
                .addGap(2, 2, 2)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxCambio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(lblportas)
                .addGap(2, 2, 2)
                .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(lblportas1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtConsultaCarro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttnAtualizarVeiculo)
                    .addComponent(bttnDeletarVeiculo)
                    .addComponent(bttnBuscarPlaca))
                .addGap(23, 23, 23))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(324, Short.MAX_VALUE)
                    .addComponent(bttnCadastrarVeiculo)
                    .addGap(95, 95, 95)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bttnCadastrarVeiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnCadastrarVeiculoActionPerformed
        this.CadastrarCarro(novoCarro);
    }//GEN-LAST:event_bttnCadastrarVeiculoActionPerformed

    private void bttnBuscarPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnBuscarPlacaActionPerformed
        this.BuscarCarro(novoCarro);
    }//GEN-LAST:event_bttnBuscarPlacaActionPerformed

    private void bttnAtualizarVeiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnAtualizarVeiculoActionPerformed
        this.AtualizarCarro(novoCarro);
    }//GEN-LAST:event_bttnAtualizarVeiculoActionPerformed

    private void bttnDeletarVeiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnDeletarVeiculoActionPerformed
        this.DeletarCarros(novoCarro);
    }//GEN-LAST:event_bttnDeletarVeiculoActionPerformed

    private void bttnMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnMenuActionPerformed
        Menu menu = new Menu();
        menu.setVisible(true);

        UICadastroCarros veiculos = new UICadastroCarros();
        dispose();
    }//GEN-LAST:event_bttnMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UICadastroCarros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UICadastroCarros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UICadastroCarros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UICadastroCarros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UICadastroCarros().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bttnAtualizarVeiculo;
    private javax.swing.JButton bttnBuscarPlaca;
    private javax.swing.JButton bttnCadastrarVeiculo;
    private javax.swing.JButton bttnDeletarVeiculo;
    private javax.swing.JButton bttnMenu;
    private javax.swing.JComboBox<String> cbxAno;
    private javax.swing.JComboBox<String> cbxCambio;
    private javax.swing.JComboBox<String> cbxCarroceria;
    private javax.swing.JComboBox<String> cbxCombustivel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblAno;
    private javax.swing.JLabel lblMarca;
    private javax.swing.JLabel lblcarroceria;
    private javax.swing.JLabel lblcor;
    private javax.swing.JLabel lblmodelo;
    private javax.swing.JLabel lblportas;
    private javax.swing.JLabel lblportas1;
    private javax.swing.JTextField txtConsultaCarro;
    private javax.swing.JTextField txtCor;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtModelo;
    private javax.swing.JTextField txtMotor;
    private javax.swing.JTextField txtPlaca;
    // End of variables declaration//GEN-END:variables
}
