/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objects;

/**
 *
 * @author alope
 */
public class Locacao {
    private String nome_locacao;
    private String data_locacao;
    private String cnh;
    private String cpf;
    private String carro_locacao;
    private String placa_locacao;
    
    public String getNome(){
        return(this.nome_locacao);
    }
    public void setNome(String nome_locacao){
        this.nome_locacao = nome_locacao;
    }
    public String getCPF(){
        return(this.cpf);
    }
    public void setCPF(String cpf){
        this.cpf = cpf;
    }
    public String getDataLocacao(){
        return(this.data_locacao);
    }
    public void setDataLocacao(String data_locacao){
        this.data_locacao = data_locacao;
    }
    public void setCNH(String cnh){
        this.cnh = cnh;            
    }
    public String getCNH(){
        return(this.cnh);
    }
    public void setLocacaoCarro(String carro_locacao){
        this.carro_locacao = carro_locacao;
    }
    public String getLocacaoCarro(){
        return(this.carro_locacao);
    }
    public String getPlacaLocacao(){
        return(this.placa_locacao);
    }
    public void setPlacaLocacao(String placa_locacao){
        this.placa_locacao= placa_locacao;
    }

}

